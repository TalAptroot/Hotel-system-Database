# SQL Hotel System Database

## Overview
This project involves the design and implementation of a relational database schema for a hotel management system using SQL. The database efficiently manages hotel resources such as rooms, reservations, and guest information, ensuring optimal data organization and retrieval.
