DELETE from Supplier;
DELETE from Staff;
DELETE from Payment;
DELETE from TodayPrice;
DELETE from Customer;
DELETE from Room;
DELETE from Hotel;
